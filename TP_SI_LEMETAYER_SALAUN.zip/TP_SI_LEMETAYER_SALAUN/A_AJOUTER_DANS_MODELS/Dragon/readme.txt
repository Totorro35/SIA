BGE Dragon 2.0

This is my black dragon design.
http://wp.me/P3dmoi-1tI

I modeled, textured and rigged this dragon in Blender from 09.11.2009 to 31.01.2010.
https://goo.gl/00X0qF

3d and animation preview on Sketchfab
https://goo.gl/bPXonA

I improved the logics so everything works fin in Blender 2.68a
and for an easy animation I have added some custom bone shapes.

I use my brushes to create the new textures.
-http://www.blendswap.com/blends/view/69739
-http://www.blendswap.com/blends/view/69653

Controls in Blenders Game Engine:
W : walk forward
Left mouse button + W: run forward
S: walk backward
W+A: walk to the left
W+D: walk to the right
Space: to spit fire
Middle mouse button : to open to the wings


3DHaupt.com
