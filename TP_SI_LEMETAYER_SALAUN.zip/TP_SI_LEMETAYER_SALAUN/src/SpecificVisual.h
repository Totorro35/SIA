#ifdef _WIN32

#pragma warning(disable: 4702)

#endif