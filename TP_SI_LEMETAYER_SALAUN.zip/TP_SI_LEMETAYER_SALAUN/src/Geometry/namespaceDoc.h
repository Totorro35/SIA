/** \brief Espace de nommage contenant les classes relatives � la gestion d'une g�om�trie */
namespace Geometry
{}